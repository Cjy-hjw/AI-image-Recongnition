"""官方比赛数据(2026 医保影像AI 赛道七)训练加载器。

把官方标注(xlsx 标注表 + `.dcm`/`.nii.gz` 影像 + NIfTI mask)转成与
`ThyroidDataset`(`src/dataset/loader.py`)**同构**的训练样本
`(img[1,H,W]f32∈[0,1], mask[1,H,W]f32, labels)`,可无改动接入
`train_step.train_batch` 的 masked-loss。

数据格式见 `docs/训练与架构/训练数据定稿.md`。**代码本地写、取数运行在云端/A800**(官方数据禁本地),
本地用合成 fixture 单测(`tests/test_official_loader.py`)。

三件套(照 `pathology_dataset.py`):
    parse_annotation_xlsx(xlsx) -> (records, colmap)   按字段名解析,禁硬编码列号
    build_official_samples(root, xlsx) -> list[sample]  静动分派 + RoiName 对 mask + masked 判据
    OfficialThyroidDataset(samples, img_size, transform) 输出同 ThyroidDataset 契约

关键铁律:
- **标签常量硬依赖 `prediction_json`,禁重定义**(Plan M3):混写单元格 `2左中叶`/`4恶性`
  解析走 `location_label_to_index` / `ete_label_to_code`,顺序/映射是单一权威定义,
  重抄会静默错位、JSON 合法但指标偏低、本地永远查不出根因。
- **masked-loss 判据 = 该临床列是否为空**(空→valid=0、有值→valid=1),逐列逐行,
  不是"是否 M 行"(定稿 §2.2:非 M 行 ~13% 也有标注)。
- **按字段名解析,禁硬编码列号**(定稿 §4.2:各轮列号不一致)。
- 患者分组切分防泄漏(rules.md §5;复用 `patient_grouped_split`)。
"""

import os
import glob
import re
import random
import sys
import unicodedata
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

import numpy as np
import cv2
import torch
from torch.utils.data import Dataset

# 水平翻转时位置标签的左右置换(单一权威,禁自定义映射)
from src.models.heads import flip_location_index

# 复用:患者分组切分(防同患者跨集泄漏,rules.md §5 铁律)
from src.dataset.pathology_dataset import patient_grouped_split
# 复用:DICOM/位深→uint8 灰度(不整段调 load_input_image——训练路径无需其 PHI 匿名化
#       语义,且函数签名带 output_dir(现仅占位);只借 _to_gray 的通道/位深收敛,
#       与推理侧口径一致。2026-09-01 起该函数已不写盘,本处不复用的理由收窄为
#       "训练无需匿名化开销",设计不变。)
from src.inference.io import _to_gray
# 复用:NIfTI 读取(动图 + mask),内含 (X,Y,Z)↔(H,W) 转置约定(定稿最易错处,勿另抄)
from src.inference.nifti_io import load_nifti_frames
# 复用:标签常量与混写解析(单一权威,禁重定义;Plan M3)
from src.inference.prediction_json import (
    location_label_to_index,
    _ETE_LABEL_TO_CODE,
    _TIRADS_ROMAN_TO_CODE,
)

# 可选依赖探测:不在模块层 import(避免 Pyright possibly-unbound + 缺失即整模块崩),
# 实际 import 在用到的函数内、HAS_* 守卫之后。
import importlib.util as _ilu
HAS_PYDICOM = _ilu.find_spec("pydicom") is not None
HAS_PANDAS = _ilu.find_spec("pandas") is not None
# pandas.read_excel(.xlsx) 的真实解析后端是 openpyxl(pandas 本身不含 xlsx 解析器)。
# 装了 pandas 但没装 openpyxl 时,pd.read_excel 抛的是 pandas 内部的晦涩
# ImportError,不会指名道姓说"装 openpyxl"——这里单独探测给出直白报错。
HAS_OPENPYXL = _ilu.find_spec("openpyxl") is not None


# ── xlsx 字段名映射(按字段名解析,禁硬编码列号) ─────────────────────────────
# 每个逻辑字段给多个候选列名,命中 DataFrame 里第一个存在的列。官方表头为中文。
# ⚠️ 部分列名需对**真实 xlsx** 复核后锁定(数据禁本地,在云端/A800 验)。字段名式
#    解析意味着:只需增改这里的候选名即可适配,不动下方逻辑。已确认的列名有据可依:
#      图像性质 / ANNOTATION->SliceIndex(定稿 §4.2)、主病灶位置(prediction_json 注释)、
#      ROI良恶性 写"恶/良"(定稿 §1.7)。其余为合理候选,真实表复核后收敛。
_FIELD_ALIASES: Dict[str, Tuple[str, ...]] = {
    "patient_id":     ("PatientId", "患者ID", "患者编号", "patient_id"),
    "series_uid":     ("SeriesUid", "SeriesInstanceUID", "序列UID"),   # 静态图=磁盘子目录名
    # 🔴 **可选列,不是必需列**。官方 74 列表头里没有「图像性质」(数据集概况.md 列0-73
    # 全量清单)。静动判据已改为探测磁盘扩展名,本列仅在存在时做一致性校验。保留候选名
    # 是为了"若某轮数据真有这列就顺手校验",不命中完全不影响训练。
    "image_property": ("图像性质", "ImageProperty", "图像类型"),        # 1=静态 2=动态
    "roi_name":       ("RoiName", "ROI名称", "roi_name"),
    "slice_index":    ("ANNOTATION->SliceIndex", "SliceIndex"),        # 1-based 帧号
    # 临床标签列。列号依据 `docs/8.1赛事公开资料/数据集概况.md`(74 列全量清单):
    # 52 良恶性 / 53 TI-RADS / 59 甲状腺外侵犯 / 60 主病灶位置 / 61 临床T分期。
    # ⚠️ 候选名的空格/全角/大小写差异已由 `_resolve_columns` 的归一化匹配兜住,
    #    **不需要**为 `甲状腺 外侵犯` 这类空格变体单独加一条候选名。
    "malignancy":     ("ROI->CLINICAL->良恶性", "ROI良恶性", "良恶性"),  # 恶/良/无
    "lesion_loc":     ("主病灶位置", "病灶位置", "lesion_loc"),          # 混写 2左中叶
    "extrathy_ext":   ("甲状腺外侵犯", "ETE", "extrathy_ext"),           # 混写 2甲状腺包膜
    "clin_t_stage":   ("临床T分期", "T分期", "clin_t_stage"),           # 混写 1有 / 0无
    # TI-RADS 总分类(非"详细评分子项",两者是不同粒度的列,定稿 §2.2)。
    # `ROI->CLINICAL->TI-RADS`(列53)放第一位。⚠️ 末位 `ROI->CLINICAL->TI-RDAS` 是官方表
    # 列54 的**拼写错误冗余列**(RDAS≠RADS,数据集概况.md 已标注),正常应命中列53;放在
    # 最后仅作兜底,防列53 缺失时彻底零监督。切勿把它排到前面——两列同信息时应优先正确列。
    "tirads":         ("ROI->CLINICAL->TI-RADS", "ROI-TIRADS", "TI-RADS",
                        "TIRADS", "TI_RADS", "TI-RADS分类", "TI-RADS总分类",
                        "ROI->CLINICAL->TI-RDAS"),
    # CBM 概念子标签(列名/编码映射待真实表复核;命中则按数字前缀解析,缺失→valid=0)
    "composition":    ("成分", "composition"),
    "echogenicity":   ("回声", "echogenicity"),
    "shape":          ("形状", "纵横比", "shape"),
    "margin":         ("边缘", "margin"),
}

# RoiName:主病灶标识 = "M";次病灶 = "病灶1".."病灶N"(定稿 §1.4)。
MAIN_LESION_ROI = "M"
_SECONDARY_ROI_RE = re.compile(r"^病灶\d+$")
# 关键帧/开始/结束行仅坐标、无临床标签,不构成分类/分割样本(定稿 §2.3),
# 由 _is_lesion_roi 只放行 M/病灶N 隐式排除。

# CBM 概念任务(与 loader.py / train_step 一致);官方列名/编码未锁前默认 valid=0。
_CONCEPT_TASKS = ("composition", "echogenicity", "shape", "margin")


# ── 单元格解析工具 ──────────────────────────────────────────────────────────
def _cell_str(v) -> str:
    """单元格 → 去空白字符串;NaN/None/空 → ""。"""
    if v is None:
        return ""
    if isinstance(v, float) and np.isnan(v):
        return ""
    s = str(v).strip()
    return "" if s.lower() in ("", "nan", "none") else s


def _is_empty(v) -> bool:
    """masked-loss 判据:该列是否为空(空→该任务 valid=0,不回传梯度)。"""
    return _cell_str(v) == ""


def _digit_prefix(v) -> Optional[int]:
    """取单元格的数字前缀(混写 `2左中叶`→2、`1有`→1);无数字前缀→None。"""
    m = re.match(r"^\s*(\d+)", _cell_str(v))
    return int(m.group(1)) if m else None


def _parse_malignancy(v) -> Optional[int]:
    """ROI良恶性 → 0良/1恶。定稿 §1.7:该列写"恶"/"良"(无数字前缀);兼容"1阳性/4恶性"。"""
    s = _cell_str(v)
    if not s:
        return None
    if "恶" in s or "阳" in s:
        return 1
    if "良" in s or "阴" in s:
        return 0
    d = _digit_prefix(s)          # 兜底:数字编码(极少见)
    return None if d is None else int(d != 0)


def _parse_t_stage(v) -> Optional[int]:
    """临床T分期 → 0无/1有。混写 `1有`/`0无`:数字前缀优先,回退中文。"""
    s = _cell_str(v)
    if not s:
        return None
    d = _digit_prefix(s)
    if d is not None:
        return int(d != 0)
    if "有" in s:
        return 1
    if "无" in s:
        return 0
    return None


def _parse_ete_code(v) -> Optional[int]:
    """甲状腺外侵犯 → 输出码 1..4(1无 2包膜 3软组织 4血管);空/未知/阴性→None。

    ⚠️ **不可回退 `ete_label_to_code`**:它对任何未知串按最保守 1"无"处置——那是
       **输出侧**策略(占位不丢分),训练侧套用会把真侵犯样本(如标注 `侵犯前纵膈`)当
       "无侵犯"学,污染梯度、违反"未知→valid=0"铁律(审查 S3)。

    ⚠️ **同样不可直接吃 `_ETE_LABEL_TO_CODE` 全表**(审查 S3 Finding1 / 与 S4 一致):
       该表含输出侧的 `NA/UNK`、`无病灶（阴性）`→码1 归并项;训练侧这些是"未知/阴性",
       必须 valid=0(阴性无结节→无侵犯可评,同位置/ETE 的 S4 决策),故先显式排除再匹配。

    解析优先级:① 显式排除 `阴性`/`无病灶`(**优先于数字前缀**——阴性行即便被打了 ETE
    数字码也不入侵犯训练,与 S4 一致)→None;② 数字前缀 1..4(混写 `2甲状腺包膜`,前缀即
    官方码);③ 剥前缀后 `NA`/`UNK` 等→None;④ 规范标签精确命中 `_ETE_LABEL_TO_CODE`
    才返码(含 0-based 变体 `0无`→中文"无"→1);⑤ 其余→None→valid=0(安全丢弃不污染)。

    @云TODO(真实 xlsx 到位复核):非规范措辞(`无侵犯`/`毗邻软组织侵犯` 这类含关键词但非
       规范短标签)当前 safe-drop 到 valid=0(仅欠采、不误标)。届时须按真实措辞重锁 Chinese
       matcher——但**禁激进子串匹配**(否定陷阱:`无血管侵犯` 含"血管"会误判血管侵犯)。
       digit-prefix 路径覆盖定稿确认的混写常态(`1无侵犯`/`3毗邻软组织` 等带前缀),是可靠主路。
    """
    if _is_empty(v):
        return None
    s_full = _cell_str(v)
    # 阴性/无病灶 → None,**优先于数字前缀**(S3 Finding1 + S4:阴性无结节→无侵犯可评)。
    if ("阴性" in s_full) or ("无病灶" in s_full):
        return None
    d = _digit_prefix(v)
    if d is not None and 1 <= d <= 4:
        return d                                # 混写:数字前缀即官方输出码 1..4
    # 剥数字前缀取中文/字母部分;NA/UNK 等未知记号 → None(不吃 _ETE_LABEL_TO_CODE 的归并项)。
    s = re.sub(r"^\s*\d+\s*", "", s_full).strip()
    if s.upper() in ("NA/UNK", "NA", "N/A", "UNK", "UNKNOWN"):
        return None
    return _ETE_LABEL_TO_CODE.get(s)            # 规范标签精确命中才认;未知措辞→None(valid=0)


def _parse_tirads(v) -> Optional[int]:
    """TI-RADS 总分类 → 输出码 1..5;空/未知/越界→None。

    定稿 §1.7:真实字面是**罗马数字+"类"**(`V类`,无数字前缀),但同表另有列用
    "数字+空格+罗马"混写(`5 V类`);两条路都要走。

    解析优先级:① 空→None;② 数字前缀 1..5(混写路径,前缀即官方码);③ 剥前缀后
    归一化(去空白/全角转半角/大写/去尾缀"类"|"级")在 `_TIRADS_ROMAN_TO_CODE`
    **精确查表**才返码;④ 其余(NA/UNK/未评估/越界数字)→None→valid=0。

    🔴 **禁子串 `in` 匹配**:"IV" 含 "I"、"III" 含 "II"/"I",子串匹配会把 IV/III
    误判成 I/II。精确 dict 查表天然避免这个坑(与 `_parse_ete_code` 同一教训)。
    """
    if _is_empty(v):
        return None
    s_full = _cell_str(v)
    d = _digit_prefix(v)
    if d is not None and 1 <= d <= 5:
        return d                                 # 混写:数字前缀即官方输出码 1..5
    # 剥数字前缀,归一化后在罗马数字表精确查找(不做子串匹配)。
    s = re.sub(r"^\s*\d+\s*", "", s_full).strip()
    s = unicodedata.normalize("NFKC", s)          # 全角→半角、兼容字符归一
    s = re.sub(r"(类|级)\s*$", "", s).strip().upper()
    if not s:
        return None
    return _TIRADS_ROMAN_TO_CODE.get(s)           # 精确命中才认;未知措辞→None(valid=0)


def _parse_concept(v) -> Optional[int]:
    """CBM 概念(成分/回声/形状/边缘)→ 0-based 类索引 = 数字前缀-1。无前缀→None。

    🔴 **2026-09-26 R2 review P0-1 定案:官方表无独立概念列,此函数在生产
    xlsx 上恒 None(监督结构性恒空)**。实测依据(数据探查证据链第13轮,
    真实表头列 40-51 全序列):`ROI->CLINICAL->良恶性(40) / ROI->CLINICAL->
    TI-RADS(41) / 主病灶标记(42) / 甲状腺癌存在标签(43) / ACR-TI-RADS分类(44)
    / 病理结果-组织学(45) / 甲状腺外侵犯(46) / 主病灶位置(47) / 临床T分期(48)
    / 临床N分期(49) / 临床M分期(50) / TI-RADS详细评分(51)`——**没有**
    成分/回声/形状/边缘 独立列;`_FIELD_ALIASES` 候选名归一化永不命中 →
    valid_*=0 全程静默。概念信息只存在于 `TI-RADS详细评分` 的复合串
    (`成分:2分,回声:2分,形态:0分,边缘:0分,强回声:0分`,全表缺失 84.4%),
    复合串格式 `成分:2分` 经数字前缀解析得 None(实测)。
    → **ROI 概念监督(concepts_roi/债6)在官方数据上当前不可开**;
    roi_concept_weight 保持 0;若将来要开,须:① 拆复合串解析(非数字前缀
    列);② 与 TN3K 公开集口径对齐类索引(R2 P0-2:TN3K shape 用 h>w,
    官方"形态:0分"=宽>高,两条链同类号反义;echo TN3K 仅 2 类,
    官方 3/4 档公开集恒不存在)。二者都是数据侧前置,不是本函数内改
    一个映射能解决的。
    """
    d = _digit_prefix(v)
    return None if d is None or d < 1 else d - 1


# ── xlsx 解析 ───────────────────────────────────────────────────────────────
def _normalize_col(name: str) -> str:
    """列名归一化:去所有空白 + 全角转半角 + 转小写。

    🔴 **不要退回精确匹配**。官方 xlsx 的表头存在同一字段的多种书写变体,精确匹配
    (`a in cols`)对下列任一差异都会静默漏掉,而漏掉临床列**不报错**、只是该头全程
    `valid_*=0` 零监督(最隐蔽的失败模式):
      - 空格变体:云端实测报告过 `甲状腺 外侵犯`(中间有空格),而 `docs/8.1赛事公开
        资料/数据集概况.md` 列59 记的是 `甲状腺外侵犯`(无空格)。两个来源矛盾,归一化
        后二者等价,不必赌哪个对。
      - 全角/半角:`ＴＩ－ＲＡＤＳ` vs `TI-RADS`、全角括号与减号。
      - 大小写:`PatientId` vs `patientid` vs `PATIENTID`。
    归一化只用于**匹配**,`colmap` 里存的仍是 DataFrame 的原始列名(取值时必须用原名)。
    """
    s = unicodedata.normalize("NFKC", str(name))
    return "".join(s.split()).lower()


def _resolve_columns(columns) -> Dict[str, Optional[str]]:
    """逻辑字段 → DataFrame 实际列名(候选里第一个存在的);找不到记 None。

    两轮匹配:先精确(最快、最不容易误命中),再归一化(容忍空格/全角/大小写变体)。
    返回的始终是**原始列名**,供 `row[col]` 取值。
    """
    cols = list(columns)
    norm_to_orig: Dict[str, str] = {}
    for c in cols:
        # 首个命中优先:同一归一化键有多列时(如冗余的拼写错误列),保留靠前的那个,
        # 与精确匹配"候选顺序即优先级"的语义一致。
        norm_to_orig.setdefault(_normalize_col(c), c)

    colmap: Dict[str, Optional[str]] = {}
    for logical, aliases in _FIELD_ALIASES.items():
        hit = next((a for a in aliases if a in cols), None)
        if hit is None:
            hit = next((norm_to_orig[k] for a in aliases
                        if (k := _normalize_col(a)) in norm_to_orig), None)
        colmap[logical] = hit
    return colmap


def parse_annotation_xlsx(
    xlsx_path: str, sheet_name: str = "ROI级别"
) -> Tuple[List[Dict], Dict[str, Optional[str]]]:
    """读官方标注表的 ROI 级别 sheet,**按字段名**抽列,返回逐 ROI 行 record。

    Returns:
        (records, colmap)
        records — list[dict],每 dict 键为逻辑字段名(见 _FIELD_ALIASES),值为原始单元格。
        colmap  — 逻辑字段 → 命中的真实列名(None 表示该列在表中缺失)。

    Raises:
        RuntimeError: pandas 或 openpyxl 未安装。
        KeyError:     关键列(patient_id / roi_name)全候选名皆缺失
                      —— 宁可显式报错,不静默产出空样本集。
                      ⚠️ `image_property` **不在**此列表(2026-08-14 实测:官方表无该列),
                      它缺失只走软降级,详见函数体内注释。
    """
    if not HAS_PANDAS:
        raise RuntimeError("pandas 未安装,无法读 .xlsx 官方标注表")
    if not HAS_OPENPYXL:
        raise RuntimeError(
            "openpyxl 未安装,无法读 .xlsx 官方标注表(pandas.read_excel 的实际"
            "解析后端)。训练环境请先 `pip install -r requirements-train.txt`。"
        )
    import pandas as pd
    # dtype=str 保留 `2左中叶` 原样,避免 pandas 把纯数字列转成 float 引入 `2.0`。
    # header=1:官方 xlsx 用合并单元格表头,真实列名(PatientId/ROI->CLINICAL->良恶性等)
    # 在第2行(0-based row=1),第1行是合并单元格的分组标题。云端 2026-08-13 用真实官方数据
    # 实测确认——header=0(默认)会把分组标题当列名,导致 _FIELD_ALIASES 全部候选名零命中、
    # 四头全程静默 valid=0(不报错,是最隐蔽的失败模式)。header=1 后列名匹配率 100%(5/5)。
    df = pd.read_excel(xlsx_path, sheet_name=sheet_name, header=1, dtype=str)
    colmap = _resolve_columns(df.columns)

    for key in ("patient_id", "roi_name"):
        if colmap[key] is None:
            raise KeyError(
                f"官方标注表缺关键列 `{key}`(候选名 {_FIELD_ALIASES[key]} 均未命中)。"
                f"表头实为 {list(df.columns)} —— 请据真实表更新 _FIELD_ALIASES。"
            )
    # 🔴 `image_property` **不在**必需列里(2026-08-14 云端真数据实测修正)。
    # 官方 74 列表头中根本没有「图像性质」这一列(`docs/8.1赛事公开资料/数据集概况.md`
    # 列 0-73 全量清单可查),此前把它列为必需列导致真数据一进来必 KeyError。
    # 根因不是列名写错,是**我方从未核实过该列存在**:证据链 14 轮里它只在第一轮出现过
    # 一次、原文写的是"推断为图像性质列,需 Excel 验证",却被当成已确认写进了代码注释。
    # 现在静动判据改为**探测磁盘文件扩展名**(见 build_official_samples),那是定稿 §1.3
    # 「.dcm=静 / .nii.gz=动,全量互斥 0 混合」的直接证据,也与推理侧按扩展名分发一致,
    # 比表里的字段更可靠。该列若真存在则作为**辅助校验**使用,不存在也不影响训练。

    records: List[Dict] = []
    for _, row in df.iterrows():
        records.append(
            {logical: (row[col] if col is not None else None)
             for logical, col in colmap.items()}
        )
    return records, colmap


def _row_img_dir(root: str, pid: str, rec: Dict,
                patient_is_dynamic: bool) -> Tuple[bool, str]:
    """行级 img_dir 解析(主循环与 L2 union 收集器共用,单一权威)。

    判据与 build_official_samples 主循环逐位同源:患者级磁盘探测为主,
    **行级 series 目录兜底**(患者同时有动态 nii 与静态 .dcm 时按静态)。
    返回 (is_dynamic, img_dir)。
    """
    is_dynamic = patient_is_dynamic
    if is_dynamic:
        _series = _cell_str(rec.get("series_uid"))
        if _series and glob.glob(os.path.join(root, pid, _series, "*.dcm")):
            is_dynamic = False
    if is_dynamic:
        return True, os.path.join(root, pid, pid)
    _series = _cell_str(rec.get("series_uid"))
    img_dir = os.path.join(root, pid, _series) if _series else os.path.join(root, pid)
    return False, img_dir



# ── 样本构造 ────────────────────────────────────────────────────────────────
def _is_lesion_roi(roi_name: str) -> bool:
    """是否为构成分类/分割样本的病灶行(M 或 病灶N);关键帧/开始/结束行返回 False。"""
    s = _cell_str(roi_name)
    return s == MAIN_LESION_ROI or bool(_SECONDARY_ROI_RE.match(s))


def _mask_path_for_roi(img_dir: str, roi_name: str) -> Optional[str]:
    """按 RoiName 定位 mask 文件:M→`M_1_mask.nii.gz`、病灶N→`病灶N_N_mask.nii.gz`。

    用 glob 而非硬拼数字(定稿写 `病灶N_N_mask.nii.gz`,但第二段编号不完全确定),
    命中第一个;找不到返回 None。

    🔴 **两种命名都要收(2026-08-13 Gate2 加固)**:`{roi}_*_mask.nii.gz` 里的 `*`
    在 fnmatch 语义下**至少吃一个字符**,所以该模式结构性地匹配不上无编号的裸
    `M_mask.nii.gz`。定稿 §1.4/§2/§3 三处均写实测命名为 `M_1_mask.nii.gz`(带段编号),
    故当前不触发;但万一官方数据里存在无编号变体,漏匹配是**静默失败** ——
    mask_path=None → `valid_mask=0` → 主病灶分割监督消失,动态路线还会因定位不到
    非零帧而整例跳过(:379),全程不报错、不告警,只是分数莫名偏低。官方数据禁本地、
    上云只有一次机会,多 glob 一次的成本是零。
    排序后取第一个:带编号的 `M_1_mask` 天然排在 `M_mask` 之前('1'<'m'),
    即两者并存时仍优先用定稿实测的那种命名。
    """
    roi_s = _cell_str(roi_name)
    hits = sorted(
        glob.glob(os.path.join(img_dir, f"{roi_s}_*_mask.nii.gz"))
        + glob.glob(os.path.join(img_dir, f"{roi_s}_mask.nii.gz"))
    )
    return hits[0] if hits else None


def _build_labels(rec: Dict, patient_id: str, lesion_id: str = "") -> Dict:
    """从一条 ROI record 构造 labels dict(同 ThyroidDataset 键 + 三新维度 + valid_*)。

    masked-loss 判据:每个任务的 `valid_{task}` = 该临床列**非空**才 1。空 → 0 + 占位值,
    下游 masked-loss 零梯度(定稿 §2.2:判据是列是否为空,不是是否 M 行)。

    `is_main`/`lesion_id` 供验证侧复现官方评分口径(评审规则:三新维度"仅针对匹配成功的
    主病灶"评估;动态数据分类指标按**病灶级**汇总、每病灶只贡献一个样本)——只有 labels
    dict 会随 `__getitem__` 进 batch,加在 sample base 里到不了训练循环。
    """
    labels: Dict = {"patient_id": patient_id}
    roi = _cell_str(rec.get("roi_name"))
    labels["is_main"] = int(roi == MAIN_LESION_ROI)
    labels["lesion_id"] = lesion_id or f"{patient_id}::{roi}"

    # 良恶性
    # ⚠️ 审查 S4:"阴性"→良性(0)+valid=1(有效负样本),与位置/ETE 对阴性置 valid=0
    #    **刻意不一致**——阴性病例"确定良性"是恶性头需要的负例;而"无结节可定位、无侵犯
    #    可评"使位置/ETE 天然无监督对象。语义自洽,非 bug。
    #    @云TODO:官方数据里阴性是否真以 ROI 行出现待验(ROI=病灶区,阴性可能根本无 ROI
    #    行→此路径不触发,阴性走患者级空 prediction.json)。云端验证 official_loader 时确认。
    mal = _parse_malignancy(rec.get("malignancy"))
    labels["malignancy"] = 0 if mal is None else mal
    labels["valid_malignancy"] = int(mal is not None)

    # 位置(0..6,复用权威解析;None=阴性/未知→不参与位置损失)
    loc = location_label_to_index(rec.get("lesion_loc"))
    labels["lesion_loc"] = 0 if loc is None else int(loc)
    labels["valid_lesion_loc"] = int(loc is not None and not _is_empty(rec.get("lesion_loc")))

    # 甲状腺外侵犯:输出码 1..4 → 训练 0-based 类索引 (码-1)。空列→valid=0。
    ete_code = _parse_ete_code(rec.get("extrathy_ext"))
    labels["extrathy_ext"] = 0 if ete_code is None else int(ete_code - 1)
    labels["valid_extrathy_ext"] = int(ete_code is not None)

    # 临床T分期(0/1)
    t = _parse_t_stage(rec.get("clin_t_stage"))
    labels["clin_t_stage"] = 0 if t is None else t
    labels["valid_clin_t_stage"] = int(t is not None)

    # TI-RADS 总分类:输出码 1..5 → 训练 0-based 类索引(码-1)。指标"仅匹配成功的主
    # 病灶"、**不带**恶性限定(与 ETE/T 不同,评审规则原文无"且为恶性")。空列→valid=0。
    tirads_code = _parse_tirads(rec.get("tirads"))
    labels["tirads"] = 0 if tirads_code is None else int(tirads_code - 1)
    labels["valid_tirads"] = int(tirads_code is not None)

    # CBM 概念(成分/回声/形状/边缘):列名/编码未锁前,命中列则按数字前缀-1,否则 valid=0
    for task in _CONCEPT_TASKS:
        val = _parse_concept(rec.get(task))
        labels[task] = 0 if val is None else val
        labels[f"valid_{task}"] = int(val is not None)
    # foci 为 4 维多标签,官方列/编码未定 → 占位零 + valid=0(masked-loss 跳过)
    labels["foci"] = torch.zeros(4, dtype=torch.float32)
    labels["valid_foci"] = 0

    return labels


# 三头 + TI-RADS 训练监督的实际来源列;命中列名候选表(_FIELD_ALIASES)全数缺失
# 就等于该任务零监督——`_resolve_columns` 是精确字符串匹配、缺列不报错、只让
# valid_*=0 全程静默。上云后第一时间用这个诊断确认列名候选是否命中真实表头。
# 🔴 R2 review P1-2 修(2026-09-26):四概念并入告警名单——ROI 概念监督
# (concepts_roi,债6)的标签来源就是这四个逻辑字段,列名 miss = 概念监督
# 恒空静默(比四头更隐蔽:损失恒 0 与"概念简单已收敛"不可分)。实测(证据链
# 第13轮,列40-51 全序列):官方表**无**独立 成分/回声/形状/边缘 列,概念
# 信息只在 TI-RADS详细评分(列51)复合串里(缺 84.4%)→ 告警必响,恰好
# 是"监督不可开"的正确首屏信号。
_CLINICAL_LOGICAL_FIELDS = (
    "malignancy", "lesion_loc", "extrathy_ext", "clin_t_stage", "tirads",
    "composition", "echogenicity", "shape", "margin",
)


def _safe_print(msg: str) -> None:
    """编码安全的 print —— 本模块所有诊断输出都必须走这里。

    🔴 **不要退回裸 print**:本模块的诊断信息全是中文,而云端官方容器常见
    `LANG=C`/`POSIX` locale(`sys.stdout.encoding` 为 ascii),Windows 中文控制台
    则是 gbk。两者下 `print("临床列命中:...")` 都会 `UnicodeEncodeError` **直接
    崩掉训练**,而崩点恰好是"列名没命中、最需要看到告警"的时候。
    实测:`PYTHONIOENCODING=ascii python -c "print('中文')"` → UnicodeEncodeError。
    注意崩的是**中文本身**不是 emoji —— 只删 emoji 不解决问题。
    这里退化成 `?` 也远好过让训练崩在一行日志上。
    """
    try:
        print(msg)
    except UnicodeEncodeError:
        enc = getattr(sys.stdout, "encoding", None) or "ascii"
        print(msg.encode(enc, "replace").decode(enc, "replace"))


def _warn_missing_clinical_columns(colmap: Dict[str, Optional[str]]) -> None:
    """`build_official_samples` 启动时打印临床列命中摘要,未命中项显式 warning。

    不 raise(真实表可能确实缺某列,不该阻塞训练启动),但必须在训练日志第一屏
    可见——否则某个逻辑字段的候选列名全部未命中真实表头,会零监督且全程无提示,
    直到指标离奇偏低才被发现(`_resolve_columns` 本身对此完全沉默)。
    """
    missing = [f for f in _CLINICAL_LOGICAL_FIELDS if colmap.get(f) is None]
    hit = {f: colmap[f] for f in _CLINICAL_LOGICAL_FIELDS if colmap.get(f) is not None}
    _safe_print(f"--> [official_loader] 临床列命中:{hit}")
    if missing:
        _safe_print(
            f"--> [official_loader] ⚠️ 以下逻辑字段未命中任何候选列名(该任务将零监督,"
            f"valid_*=0 全程静默):{missing}。核对 _FIELD_ALIASES 候选名与真实表头是否一致。"
        )


def build_official_samples(
    root: str, xlsx_path: str, sheet_name: str = "ROI级别",
    union_mask: bool = False,
    roi_meta: bool = False,
) -> List[Dict]:
    """扫描官方标注 + 影像目录,构造样本列表(照 pathology_dataset 的 build_* 模式)。

    分派(定稿 §1.11):静态 `{pid}/{series_uid}/*.dcm`;动态 `{pid}/{pid}/{pid}.nii.gz`。
    mask 靠 RoiName。动态:一个非零 mask 帧 = 一个样本(共享该结节标签,@云TODO:是否
    覆盖全部非零帧、精确子路径待真实数据复核)。无影像/无标注 → 跳过。

    Returns:
        list[sample dict],每项:
          img_path, mask_path(可 None), frame_index(动态为原始 0-based 帧号;静态 None),
          is_dynamic(bool), patient_key(=pid,供 patient_grouped_split), label(=malignancy,
          供分层), labels(完整 labels dict);
          union_mask=True 时额外携带 union_mask_paths(list[str],同图全部病灶 mask 路径,
          像素级并集由读取端合成 —— 静态在 __getitem__,动态在 preextract_dynamic 导出);
          roi_meta=True 时额外携带 roi_lesions(list[dict]):该样本**影像**(同 img_dir
          下全部 GT 病灶)的 per-lesion 元数据,每 dict =
          {bbox_xyxy(原图像素,半开区间)/orig_w/orig_h/spacing_mm(恒 None,见下)/
          lesion_id/label 子集(loc/ete/t/tirads/malignancy 的值+valid_*)/is_main/
          frame_indices(动态病灶全部非零帧;静态 None)}。🔴 默认 False:旧调用
          (preextract/train_official 等)零变化,旧 samples.pkl 无该键,消费端
          (`roi_dataset.py`)判键存在再用。**旧 pkl + roi_meta=True 的组合不会
          重建 pkl——roi_meta 只影响 build 路径,pkl 路径载入的旧样本无键,
          下游判 `"roi_lesions" not in s` 降级,允许(与 union 的硬拒不同:
          roi_lesions 是元数据增强不是监督语义,半开态只会让 ROI 采样器跳过
          无键样本,不会让监督"号称开了实际没开")。**

    spacing_mm 说明:官方影像侧无 spacing 可读(NIfTI 仿射是单位阵,nifti_io.py
    `save_binary_mask` 注释;DICOM PixelSpacing 未在训练消费链出现过,云端
    亦未实测报告)——**不得编造**(推断不得进硬失败路径,2026-08-14 教训),
    恒 None 透传,物理 mm 尺度留给消费端(如 physical_diameter_from_mask)
    在拿到真实 spacing 来源后再接。
    """
    records, colmap = parse_annotation_xlsx(xlsx_path, sheet_name)
    _warn_missing_clinical_columns(colmap)

    by_patient: Dict[str, List[Dict]] = defaultdict(list)
    for rec in records:
        pid = _cell_str(rec.get("patient_id"))
        if pid:
            by_patient[pid].append(rec)

    samples: List[Dict] = []
    for pid, recs in by_patient.items():
        # L2 union 监督(plan 任务 L2,2026-09-22):union_mask=True 时,同图全部 GT
        # 病灶的分割监督合并为二值并集。本函数只负责"收集同图全部 mask 路径"写进样本
        # (新增键 union_mask_paths);像素级 OR 合成在消费端(OfficialThyroidDataset/
        # preextract_dynamic),mask_path 键本身不动 —— 诊断侧 GT 逐病灶装载零影响。
        # 动态帧号语义(预注册):样本的 frame_index 不变(各病灶自己的非零帧),
        # union 在"该帧实际有哪些病灶 mask"层面合成(同帧 OR;不同帧各帧各的并集)。
        # 静动判据 = **磁盘文件扩展名**(定稿 §1.3:.dcm 静 / .nii.gz 动,全量互斥 0 混合)。
        # 不用表里的「图像性质」列:官方 74 列表头中没有该列(见 parse_annotation_xlsx 注释)。
        # 每患者探一次(静动是患者级属性),避免逐行重复 I/O。
        dyn_path = os.path.join(root, pid, pid, f"{pid}.nii.gz")
        patient_is_dynamic = os.path.exists(dyn_path)
        # 若表里恰好存在该列,取患者级非空值做**一致性校验**(不参与判定,只在冲突时告警),
        # 便于发现"磁盘与标注表不一致"这类上游数据问题。
        patient_prop = next((_digit_prefix(r.get("image_property"))
                             for r in recs if not _is_empty(r.get("image_property"))), None)
        if patient_prop is not None and (patient_prop == 2) != patient_is_dynamic:
            _safe_print(f"--> [official_loader] ⚠️ 患者 {pid} 静动判据冲突:"
                        f"表列图像性质={patient_prop}(1静/2动) 但磁盘 {'有' if patient_is_dynamic else '无'} "
                        f"{pid}.nii.gz —— 以磁盘为准继续。")

        _union_by_dir: Dict[str, List[str]] = {}
        if union_mask:
            for rec in recs:
                _roi = _cell_str(rec.get("roi_name"))
                if not _is_lesion_roi(_roi):
                    continue
                # 🔴 判据必须与主循环同源(_row_img_dir,单一权威):首版收集器
                # 独立重判静动(漏行级 series 兜底),混合患者下归错 img_dir →
                # union_mask_paths 静默为空(审查 P1-1,2026-09-22 修)。
                _is_dyn, _img_dir = _row_img_dir(root, pid, rec, patient_is_dynamic)
                _mp = _mask_path_for_roi(_img_dir, _roi)
                if _mp is not None:
                    _union_by_dir.setdefault(_img_dir, [])
                    if _mp not in _union_by_dir[_img_dir]:
                        _union_by_dir[_img_dir].append(_mp)

        # ROI 范式数据面(2026-09-25):同图全部 GT 病灶的 per-lesion 元数据,
        # 按 img_dir 作用域收集(与 _union_by_dir 同构)。病灶行 → labels 由
        # _build_labels 构造(与主循环同一次调用,零重复解析);bbox/原图尺寸/
        # 非零帧由 _roi_lesion_meta 从 mask 文件算出。**每个 mask 文件只解压
        # 一次**(进程内 memo,与 _UNION_READABLE_CACHE 同款考量:同图样本共享
        # mask 集,逐病灶真解压 = 同一文件解 N 遍;这里无"跨构建失效"问题——
        # build_official_samples 单次调用内构造、结果直接进样本 dict,不落
        # 全局缓存,函数返回即释放)。
        _roi_by_dir: Dict[str, List[Dict]] = {}
        if roi_meta:
            _meta_memo: Dict[str, Optional[Dict]] = {}
            for rec in recs:
                _roi = _cell_str(rec.get("roi_name"))
                if not _is_lesion_roi(_roi):
                    continue
                _is_dyn, _img_dir = _row_img_dir(root, pid, rec, patient_is_dynamic)
                _mp = _mask_path_for_roi(_img_dir, _roi)
                # lesion_id 与主循环同式(:596 mask_path or img_dir::roi),
                # 同一病灶多帧(动态)共享同一 id——键唯一性是病灶级聚合前提。
                _lid = _mp or f"{_img_dir}::{_roi}"
                _existed = any(d["lesion_id"] == _lid
                               for d in _roi_by_dir.get(_img_dir, []))
                if _existed:
                    continue          # 同 img_dir 同病灶去重(动态多帧只进一次)
                _labels = _build_labels(rec, pid, lesion_id=_lid)
                if _mp is None:
                    # 无 mask 文件:元数据无 bbox 可算,仍进列表(labels 可供
                    # ROI 分类训练,valid_mask=0 语义与主循环一致)。
                    # mask_path/patient_id(债2/债5,2026-09-25 训练侧接线):
                    # mask_path=None → RoiDataset 不产 roi_mask 键(forward_roi
                    # 全零兜底);patient_id 供 forward_roi 输出侧透传(数据面
                    # 原本只产 patient_key,改名成本为零一并带上)。
                    _entry = {
                        "bbox_xyxy": None, "orig_w": None, "orig_h": None,
                        "spacing_mm": None, "lesion_id": _lid,
                        "frame_indices": None,
                        "mask_path": None, "patient_id": pid,
                        **{k: _labels[k] for k in _ROI_LABEL_KEYS},
                    }
                    _roi_by_dir.setdefault(_img_dir, []).append(_entry)
                    continue
                _m = _meta_memo.get(_mp, 0) if _mp in _meta_memo else None
                if _mp not in _meta_memo:
                    _meta_memo[_mp] = _roi_lesion_meta(_mp, _is_dyn)
                    _m = _meta_memo[_mp]
                if _m is None:
                    # mask 读失败/全零:跳过该病灶的元数据(与 _static_mask
                    # 容错语义一致,不阻塞其余病灶)。
                    continue
                _entry = {
                    "bbox_xyxy": _m["bbox_xyxy"],
                    "orig_w": _m["orig_w"], "orig_h": _m["orig_h"],
                    "spacing_mm": None, "lesion_id": _lid,
                    "frame_indices": _m["frame_indices"],
                    # 债2/债5(2026-09-25 训练侧接线):GT mask 路径与患者 id
                    # 随元数据下发——RoiDataset.__getitem__ 据此裁"该样本帧"的
                    # roi_mask(与图像同一几何管线),forward_roi 输出侧读 patient_id。
                    # pkl 路径注意:roi_lesions 只在 build 路径产出,旧 pkl 无键
                    # (半开态由 roi_dataset 判键跳过,语义见 build docstring)。
                    "mask_path": _mp, "patient_id": pid,
                    **{k: _labels[k] for k in _ROI_LABEL_KEYS},
                }
                _roi_by_dir.setdefault(_img_dir, []).append(_entry)

        for rec in recs:
            roi = _cell_str(rec.get("roi_name"))
            if not _is_lesion_roi(roi):
                continue  # 关键帧/开始/结束:仅坐标,不入分类/分割样本

            # 静动判据:患者级探磁盘为主,**行级 series 目录为兜底**。
            # 主判据依据 = 证据链第10轮全量扫描 5401 个 **PatientId 目录**:仅静 5057 /
            # 仅动 343 / 混合 0(5057+343=5400≈5401 全覆盖,单位就是患者,不是子目录)。
            # 但"0 混合"终究是一次性实测结论,而误判的后果是**静默**的(静态行的标签会被
            # 挂到动态 nii.gz 上,不报错、不跳过、照常训完),故不赌它:该行若明确写了
            # series_uid 且那个目录下真有 .dcm,就按静态处理——磁盘实物比统计结论硬。
            is_dynamic = patient_is_dynamic
            if is_dynamic:
                _series = _cell_str(rec.get("series_uid"))
                if _series and glob.glob(os.path.join(root, pid, _series, "*.dcm")):
                    is_dynamic = False
                    _safe_print(
                        f"--> [official_loader] ⚠️ 患者 {pid} 同时存在动态 {pid}.nii.gz 与静态"
                        f"序列目录 {_series}(含 .dcm)——本行按**静态**处理。这与证据链第10轮"
                        f"「患者级 0 混合」矛盾,请回报此 PatientId。"
                    )

            if is_dynamic:
                img_dir = os.path.join(root, pid, pid)
                img_path = os.path.join(img_dir, f"{pid}.nii.gz")
            else:
                series = _cell_str(rec.get("series_uid"))
                img_dir = os.path.join(root, pid, series) if series else os.path.join(root, pid)
                dcms = sorted(glob.glob(os.path.join(img_dir, "*.dcm")))
                img_path = dcms[0] if dcms else None

            if not img_path or not os.path.exists(img_path):
                continue  # 无对应影像,跳过(定稿:部分检查目录在 ROI 表无对应影像)

            mask_path = _mask_path_for_roi(img_dir, roi)
            # 病灶唯一键:同一病灶的多帧(动态)必须归为一个评测样本。用 mask 路径最稳
            # (同目录同 roi 唯一);无 mask 时退回 影像目录+roi —— 同患者多序列(静态)
            # 各有自己的 img_dir,不会互相撞。
            lesion_id = mask_path or f"{img_dir}::{roi}"
            labels = _build_labels(rec, pid, lesion_id=lesion_id)
            labels["valid_mask"] = int(mask_path is not None)
            base = {
                "img_path": img_path,
                "mask_path": mask_path,
                "is_dynamic": is_dynamic,
                "patient_key": pid,
                "label": labels["malignancy"],   # 分层键(patient_grouped_split)
                "labels": labels,
            }
            if union_mask:
                # L2:同图全部病灶 mask 路径(含本病灶)。读取端见
                # OfficialThyroidDataset.__getitem__ 的 _union_mask 静态分支与
                # preextract_dynamic 的动态导出。mask_path=None 的行不进列表,
                # 与 valid_mask=0 语义一致(无 mask 行不贡献分割监督)。
                base["union_mask_paths"] = sorted(_union_by_dir.get(img_dir, []))
            if roi_meta:
                # ROI 范式数据面:同图全部病灶的元数据(收集器已按 img_dir 归好)。
                # 浅拷贝共享 list 是**故意的**:同一 img_dir 的 N 个样本(动态多帧)
                # 共享同一份元数据,病灶级语义不随样本帧变;消费端(roi_dataset)
                # 只读不改。静态样本的 "orig_w/orig_h" 与该样本影像同栅格
                # (mask 与影像同体素数)。
                base["roi_lesions"] = _roi_by_dir.get(img_dir, [])

            if is_dynamic:
                # 动态:从 mask 非零帧定位标注帧(主病灶 M 无 SliceIndex,定稿 §4.2 项6),
                # 每非零帧一样本。无 mask 则无法定位帧 → 跳过该动态病灶。
                if mask_path is None:
                    continue
                for fidx in _nonzero_mask_frames(mask_path):
                    s = dict(base)
                    s["frame_index"] = fidx
                    samples.append(s)
            else:
                s = dict(base)
                s["frame_index"] = None
                samples.append(s)

    return samples


# ── 影像 / mask 读取 ────────────────────────────────────────────────────────
def _read_dcm_gray(path: str) -> np.ndarray:
    """读静态 `.dcm` → uint8 灰度 (H,W)。复用 _to_gray(与推理侧口径一致)。"""
    if not HAS_PYDICOM:
        raise RuntimeError("pydicom 未安装,无法读官方静态 .dcm")
    import pydicom
    ds = pydicom.dcmread(path)
    return _to_gray(ds.pixel_array)


def _read_nifti_binmasks(path: str) -> Tuple[List[np.ndarray], List[int]]:
    """读 NIfTI mask 全帧 → (list[(H,W) uint8 {0,1}], frame_indices)。

    复用 load_nifti_frames 的 (X,Y,Z)↔(H,W) 转置约定(勿另抄,定稿最易错处);
    max_frames<=0 取全帧;任意非零→前景。读失败返回 ([], [])。
    """
    frames, idxs, _, err, _ = load_nifti_frames(path, max_frames=-1)
    if err or not frames:
        return [], []
    binf = [(np.asarray(f) > 0).astype(np.uint8) for f in frames]
    return binf, list(idxs)


def _nonzero_mask_frames(mask_path: str) -> List[int]:
    """动态 mask 的非零帧原始帧号(0-based)——主病灶标注帧定位口径(定稿 §4.2 项6)。"""
    binf, idxs = _read_nifti_binmasks(mask_path)
    return [idx for idx, m in zip(idxs, binf) if m.any()]


# ── per-lesion ROI 元数据(两阶段 ROI 范式 · 数据面,2026-09-25)─────────────────
# ROI 范式(方案一)第二阶段需要在**原分辨率**逐病灶裁 ROI:每条样本额外携带
# 该影像全部 GT 病灶的 bbox / 原图尺寸 / spacing / 四头标签子集,供
# `src/dataset/roi_dataset.py`(per-lesion 采样器)消费。与 L2 union 同一收集
# 范式(img_dir 作用域),但产出的是**元数据**而非像素并集——bbox 计算把每个
# mask 只解压一次(build 级 memo),动态病灶的 frame_indices 与
# `_nonzero_mask_frames` 同源同值。
def _roi_lesion_meta(mask_path: str, is_dynamic: bool) -> Optional[Dict]:
    """单个 GT mask → ROI 元数据(bbox/原图尺寸/动态非零帧)。mask 全零或读失败→None。

    bbox 口径(🔴 勿改):
    - **原图像素坐标、半开区间 xyxy**:`(x0, y0, x1, y1)` 即 `img[y0:y1, x0:x1]`
      恰为外接框(x1/y1 = 最大非零列/行 + 1)。切片语义免 ±1 歧义,ROI 裁剪端
      零换算。
    - 静态:2D mask(实为 3D 单帧,`_read_nifti_binmasks` 转回 (1,H,W))唯一非零
      帧的外接框。
    - **动态:该病灶全部非零帧的外接框之并集**(病灶在视频里的空间总幅面)。
      理由:ROI 范式按"病灶"裁,一个动态病灶的标注跨 3-5 帧,逐帧各出一个 bbox
      会让同一 lesion_id 产出多个互相矛盾的 ROI 元数据;取并集幅面是唯一与
      "per-lesion"粒度自洽的口径。消费端若需逐帧精确框,可据 `frame_indices`
      自行重算(本函数已把非零帧号一并交出)。
    - 坐标系 = `load_nifti_frames` 转置后的 (H,W) 帧坐标系(行=H、列=W),与
      `_read_dcm_gray`/`_read_nifti_frame_gray` 读出的影像帧同栅格(mask 与影像
      同体素数,定稿 §1.3),裁剪端 img[y0:y1, x0:x1] 直接可用。

    `frame_indices`:动态病灶的全部非零帧号(与 `_nonzero_mask_frames` 逐位同值,
    同一次解压的复用产物);静态恒 None(静态无帧维)。读失败(空 binf)→None,
    与 `_static_mask` 读失败返回零图的容错语义一致——收集端跳过该病灶,不阻塞
    其余病灶的元数据产出。
    """
    binf, idxs = _read_nifti_binmasks(mask_path)
    if not binf:
        return None
    h, w = binf[0].shape[:2]
    y0 = y1 = x0 = x1 = None          # None = 尚未见非零帧
    frames: List[int] = []
    for m, idx in zip(binf, idxs):
        if not m.any():
            continue
        rows = np.where(m.any(axis=1))[0]     # 非零行
        cols = np.where(m.any(axis=0))[0]     # 非零列
        ry0, ry1 = int(rows[0]), int(rows[-1])
        cx0, cx1 = int(cols[0]), int(cols[-1])
        if y0 is None:
            y0, y1, x0, x1 = ry0, ry1, cx0, cx1
        else:
            y0, y1 = min(y0, ry0), max(y1, ry1)
            x0, x1 = min(x0, cx0), max(x1, cx1)
        frames.append(int(idx))
    if y0 is None:
        return None                      # mask 存在但全零:无外接框可言
    return {
        "bbox_xyxy": (x0, y0, x1 + 1, y1 + 1),   # 半开区间:切片直接用
        "orig_w": int(w),
        "orig_h": int(h),
        "frame_indices": frames if is_dynamic else None,
    }


# ROI 元数据携带的四头标签子集(值 + valid_*;与 _build_labels 同键同口径,
# 训练侧 0-based 编码——lesion_loc 0..6 / extrathy_ext 0..3 / tirads 0..4)。
# is_main 一并携带:ROI 头损失加权按官方口径筛主病灶(评审规则:三新维度仅
# 针对匹配成功的主病灶)。
# 债6(2026-09-25,概念监督):CBM 四概念键(composition/echogenicity/
# shape/margin + valid_*)一并随元数据下发——ROI 概念头监督(concepts_roi)
# 的标签来源;foci 官方无标注恒不携带。🔴 _ROI_SCALAR_KEYS
# (roi_dataset.py)/_ROI_LABEL_RENAME 同步扩(键名单源三处同批改)。
_ROI_LABEL_KEYS = (
    "malignancy", "valid_malignancy",
    "lesion_loc", "valid_lesion_loc",
    "extrathy_ext", "valid_extrathy_ext",
    "clin_t_stage", "valid_clin_t_stage",
    "tirads", "valid_tirads",
    "is_main",
    "composition", "valid_composition",
    "echogenicity", "valid_echogenicity",
    "shape", "valid_shape",
    "margin", "valid_margin",
)


def _read_nifti_frame_gray(path: str, frame_index: int) -> np.ndarray:
    """读动态 `.nii.gz` 指定原始帧号的灰度帧 (H,W) uint8。"""
    frames, idxs, _, err, _ = load_nifti_frames(path, max_frames=-1)
    if err or not frames:
        raise RuntimeError(f"读动图失败 {path}: {err}")
    pos = idxs.index(frame_index) if frame_index in idxs else frame_index
    return np.asarray(frames[pos])


def resize_img_to(img: np.ndarray, size: int) -> np.ndarray:
    """灰度帧 → (size,size)。**训练侧 resize 口径的单一权威**,预抽取脚本必须复用本函数。

    🔴 别再抄一份:`scripts/data/preextract_dynamic.py` 把帧提前算好存 PNG,与
    `__getitem__` 现算是**同一次计算的两个时点**。两处各写一份 cv2.resize 调用,当前
    逐位一致(实测 5 种尺寸),但任何一方将来改插值方式/加抗锯齿,另一方不会跟着变 ——
    结果是缓存图与实时图悄悄不同,而 loss 照常下降、指标只是略低,本地永远查不出。
    """
    if img.shape[:2] != (size, size):
        img = cv2.resize(img, (size, size))
    return img


def resize_mask_to(mask: np.ndarray, size: int) -> np.ndarray:
    """mask → (size,size),**必须 INTER_NEAREST**(双线性会在边界造出 0/1 之外的中间值,
    虽然下游统一 `>0` 二值化不会崩,但前景面积会系统性变化)。理由同 `resize_img_to`。"""
    if mask.shape[:2] != (size, size):
        mask = cv2.resize(mask, (size, size), interpolation=cv2.INTER_NEAREST)
    return mask


def _read_cached_pair(img_png: str, msk_png: str) -> Tuple[np.ndarray, np.ndarray]:
    """读预抽取缓存的 (影像帧, mask 帧),均为 uint8 灰度 (H,W)。

    产出方是 `scripts/data/preextract_dynamic.py`,存的是 **resize 之后、增强之前**
    的那一张,与走 .nii.gz 的原路径数值等价。

    🔴 **缺文件必须抛异常,不得静默返回零图**:缓存缺失意味着预抽取没覆盖到这个样本,
    静默补零 = 拿全黑图 + 全零 mask 当真样本训(分割监督被污染、四头标签还在),
    loss 照常下降、本地永远查不出根因。宁可训练启动即崩。

    用 `np.fromfile + cv2.imdecode` 而非 `cv2.imread`:后者在非 ASCII 路径下静默
    返回 None(官方数据路径含中文的可能性不为零),错误信息与"路径编码"毫无关联。
    """
    out = []
    for p in (img_png, msk_png):
        if not p or not os.path.exists(p):
            raise RuntimeError(f"预抽取缓存缺失: {p}(重跑 scripts/data/preextract_dynamic.py)")
        a = cv2.imdecode(np.fromfile(p, dtype=np.uint8), cv2.IMREAD_GRAYSCALE)
        if a is None:
            raise RuntimeError(f"预抽取缓存解码失败(文件损坏?): {p}")
        out.append(a)
    return out[0], out[1]


# ── Dataset ────────────────────────────────────────────────────────────────
class OfficialThyroidDataset(Dataset):
    """官方数据集。输出 `(img[1,H,W]f32∈[0,1], mask[1,H,W]f32, labels)`,同 ThyroidDataset。

    labels 含现有键(composition/echogenicity/shape/margin/foci/malignancy/patient_id)
    + 三新维度(lesion_loc/extrathy_ext/clin_t_stage)+ 全部 `valid_{task}`/`valid_mask`。
    三新维度键"只产出、暂不消费"——train_step/损失接线在 Phase 2(当前忽略额外键,无害)。

    ⚠️ 性能:动态样本命中 `cache_img` 走 `_read_cached_pair`(预抽取 PNG),**不再重解码**
       `.nii.gz`;无 cache 键回落原路径(每样本全量解压影像+mask 两个体积)。预抽取见
       `scripts/data/preextract_dynamic.py`,缓存数值等价、见 `_read_cached_pair` 注释。
    """

    def __init__(self, samples: List[Dict], img_size: int = 512, transform=None,
                 hflip_prob: float = 0.0, seed: Optional[int] = None):
        self.samples = samples
        self.img_size = img_size
        self.transform = transform
        self.hflip_prob = float(hflip_prob)
        # 🔴 **生产路径必须 seed=None**(走全局 `random`,与 augmentation/transforms.py
        # 里所有增强同源):全局 RNG 由 DataLoader 的 `worker_init_fn`(seed_worker)按
        # `torch.initial_seed()` 播种,而 torch **每 epoch 创建 iterator 时重抽 base_seed**
        # → 各 worker、各 epoch 的翻转序列都不同,可复现性由主种子统一保证。
        #
        # 传固定 seed 只用于**测试确定性**。持久 `random.Random(seed)` 实例在生产会
        # 多样性塌缩:dataset 对象被 pickle 复制到每个 worker(状态相同),且
        # persistent_workers=False 时每 epoch 重建 worker 使序列重置 —— 实测三个 epoch
        # 的翻转序列**逐位相同**(不报错、loss 照常降,只是增强白做)。
        self._rng = random.Random(seed) if seed is not None else None

    def __len__(self) -> int:
        return len(self.samples)

    def _resize_img(self, img: np.ndarray) -> np.ndarray:
        return resize_img_to(img, self.img_size)      # 口径单一权威,见该函数 docstring

    def _resize_mask(self, mask: np.ndarray) -> np.ndarray:
        return resize_mask_to(mask, self.img_size)

    def __getitem__(self, idx):
        s = self.samples[idx]

        if s["is_dynamic"] and s.get("cache_img"):
            # 预抽取缓存命中(scripts/data/preextract_dynamic.py 产物)。
            # 🔴 走这条就**不碰 .nii.gz**:原路径每样本要全量解压影像+mask 两个体积
            # (各 258MB 量级、~4s),1400 动态样本 × 35 epoch ≈ 24 小时纯解压,且
            # num_workers=12 时瞬时占用 ~8.4GB —— 首轮真训的 `invalid block type`
            # 与步耗时 22 倍抖动即由此而来。缓存图是 resize 之后、增强之前的那一张,
            # 与原路径**数值等价**(见预抽取脚本 docstring),下面的 _resize_* 对它是 no-op。
            # L2 union:动态缓存在导出端已合成并集 PNG(见 preextract_dynamic 的
            # union 分支),这里读单文件即并集,无需再 OR。
            img, mask = _read_cached_pair(s["cache_img"], s["cache_msk"])
        elif s["is_dynamic"]:
            img = _read_nifti_frame_gray(s["img_path"], s["frame_index"])
            if s.get("union_mask_paths"):
                # L2 union 动态原路径:逐 mask 读该帧,OR 合成(与缓存导出端同一
                # 数学;cache miss 与无 cache 两条路径逐位一致是预注册不变式)。
                mask = self._dynamic_union_mask_frame(
                    s["union_mask_paths"], s["frame_index"])
            else:
                mask = self._dynamic_mask_frame(s["mask_path"], s["frame_index"])
        else:
            img = _read_dcm_gray(s["img_path"])
            if s.get("union_mask_paths"):
                # L2 union 静态:读同图全部 mask(每个取首帧转 2D,同 _static_mask
                # 语义),OR 合成。单病灶图(路径列表长度 1 且即本病灶 mask)结果与
                # 非 union 路径逐位一致(回归测试钉死)。
                mask = self._static_union_mask(s["union_mask_paths"])
            else:
                mask = self._static_mask(s["mask_path"])

        img = self._resize_img(img)
        mask = self._resize_mask(mask)

        # 增强在归一化前(img/mask 仍 uint8,与 ThyroidDataset/PathologyDataset 一致)
        if self.transform is not None:
            img, mask = self.transform(img, mask)

        # labels 浅拷贝 + foci 单独 clone:foci 是 _build_labels 建的**共享**零 tensor,
        # 浅拷贝会让多样本/多帧共享同一对象,下游(Phase 2 消费 foci)若原地改会跨样本
        # 污染,故克隆隔离。其余值均为不可变标量,浅拷贝安全。
        labels = dict(s["labels"])
        labels["foci"] = labels["foci"].clone()

        # 水平翻转:必须与位置标签联动。漏了会让位置头学到左右相反的监督,而 loss 照常
        # 下降(location.py:97-98 的警告)。**在 transform 之后、归一化之前**做,故本类
        # 的 transform 不得自带 HorizontalFlip(否则翻两次且标签只翻一次)。
        # RNG 取用见 `__init__`:生产走全局 random(每 worker/每 epoch 不同),
        # 仅测试传 seed 走独立实例(确定性)。
        rng = self._rng if self._rng is not None else random
        if self.hflip_prob > 0.0 and rng.random() < self.hflip_prob:
            img = np.ascontiguousarray(img[:, ::-1])
            mask = np.ascontiguousarray(mask[:, ::-1])
            if labels.get("valid_lesion_loc", 0) == 1:
                # flip_location_index 内部 `perm[idx]` 取 idx.device —— python int 直传
                # 报 AttributeError,必须包成 tensor(0-d 进 0-d 出,取值正确)。
                labels["lesion_loc"] = int(
                    flip_location_index(torch.tensor(int(labels["lesion_loc"])))
                )

        img_t = torch.tensor(img, dtype=torch.float32).unsqueeze(0) / 255.0
        mask_t = torch.tensor((mask > 0).astype(np.float32), dtype=torch.float32).unsqueeze(0)
        return img_t, mask_t, labels

    def _static_mask(self, mask_path: Optional[str]) -> np.ndarray:
        if mask_path is None:
            return np.zeros((self.img_size, self.img_size), dtype=np.uint8)
        binf, _ = _read_nifti_binmasks(mask_path)
        return binf[0] if binf else np.zeros((self.img_size, self.img_size), dtype=np.uint8)

    def _dynamic_mask_frame(self, mask_path: Optional[str], frame_index: int) -> np.ndarray:
        binf, idxs = _read_nifti_binmasks(mask_path) if mask_path else ([], [])
        if not binf:
            # 理论不达:动态样本仅在有 mask 且该帧非零时构造
            return np.zeros((self.img_size, self.img_size), dtype=np.uint8)
        pos = idxs.index(frame_index) if frame_index in idxs else frame_index
        return binf[pos]

    # ── L2 union 监督的像素合成(plan 任务 L2,2026-09-22)──────────────────────
    # 🔴 2026-09-23 云端实弹热修:OR 必须在**原始分辨率**下做。
    # 首版把累积体初始化为 (img_size, img_size),与原尺寸帧(如 958×1303)OR
    # 直接 broadcast ValueError —— 单病灶路径 _static_mask/_dynamic_mask_frame
    # 返回原尺寸帧、由 __getitem__ 统一 _resize_mask,union 版漏了对齐这一顺序。
    # 修法:惰性累积(None 起,按首帧尺寸建体),返回**原尺寸**并集,resize 完全
    # 交给 __getitem__ 的统一出口(P1-1 修:分支内不 resize,与单病灶路径语义
    # 严格一致,单一 resize 时点防两处口径漂移)。
    # 语义与单病灶路径严格同式:__getitem__ 的 resize(OR(f1..fn)) vs
    # resize(bin(f1)) —— 同一插值(INTER_NEAREST)同一时点(nearest 缩放与
    # OR 可交换,审查 72 组实证含非整数比)。
    def _static_union_mask(self, union_mask_paths: List[str]) -> np.ndarray:
        """静态:同图全部病灶 mask 首帧 OR(与 _static_mask 同"3D 单帧取首帧"语义)。

        空 mask 文件按全零处理(OR 恒等元),与单 mask 路径读失败返回零图的行为一致;
        不 raise —— build 侧已保证列表非空且各文件存在,此处读到空属上游数据个案,
        OR 语义天然吸收(其余病灶监督不受牵连)。返回**原分辨率**(与 _static_mask
        同语义,resize 归 __getitem__ 统一出口)。
        """
        out: Optional[np.ndarray] = None
        for mp in union_mask_paths:
            binf, _ = _read_nifti_binmasks(mp)
            if not binf:
                continue
            f = (binf[0] > 0).astype(np.uint8)
            if out is None:
                out = f
            else:
                out = np.logical_or(out, f).astype(np.uint8)
        if out is None:
            return np.zeros((self.img_size, self.img_size), dtype=np.uint8)
        return out

    def _dynamic_union_mask_frame(self, union_mask_paths: List[str],
                                  frame_index: int) -> np.ndarray:
        """动态:逐 mask 取该帧,OR 合成(与 preextract 导出端同一数学,逐位一致)。

        某个 mask 不含该帧(该病灶此帧无标注)→ 贡全零,OR 天然吸收;读失败同上。
        帧定位复用 _dynamic_mask_frame 的 pos 语义(idxs.index 回退 frame_index)。
        返回**原分辨率**(与 _dynamic_mask_frame 同语义,resize 归统一出口)。
        """
        out: Optional[np.ndarray] = None
        for mp in union_mask_paths:
            binf, idxs = _read_nifti_binmasks(mp) if mp else ([], [])
            if not binf:
                continue
            pos = idxs.index(frame_index) if frame_index in idxs else frame_index
            if not (0 <= pos < len(binf)):
                continue
            f = (binf[pos] > 0).astype(np.uint8)
            if out is None:
                out = f
            else:
                out = np.logical_or(out, f).astype(np.uint8)
        if out is None:
            return np.zeros((self.img_size, self.img_size), dtype=np.uint8)
        return out


def _load_samples_pkl(path: str) -> Tuple[List[Dict], Dict]:
    """加载预抽取产物 `samples.pkl` → (samples, meta)。

    格式由 `scripts/data/preextract_dynamic.py` 写出:`{"_meta": {...}, "samples": [...]}`。
    只认这一种带 `_meta` 的字典;裸 list 一律拒绝 —— 没有 meta 就无从校验 img_size,
    而 img_size 不一致是**静默掉画质**的那类 bug,不能靠"大概是对的"放行。
    """
    import pickle
    if not os.path.exists(path):
        raise RuntimeError(f"samples.pkl 不存在: {path}(先跑 scripts/data/preextract_dynamic.py)")
    with open(path, "rb") as f:
        payload = pickle.load(f)
    if not isinstance(payload, dict) or "samples" not in payload:
        raise RuntimeError(
            f"samples.pkl 格式不对(缺 'samples' 键): {path}。"
            f"须由 scripts/data/preextract_dynamic.py 生成")
    return payload["samples"], payload.get("_meta", {})


# 🔴 L2 漂移过滤的 memo 缓存(2026-09-23 启动提速):path → 是否可读。
# 同图全部 union 样本共享同一 mask 集,逐样本真解压 = 同一文件解 N 遍
# (K≥2 图 3.44 帧/病灶 × K)。**故意的全局可变缓存**:
# - 无并发写(build_official_datasets 在 DataLoader worker fork 前的主进程
#   单线程跑;fork COW 快照语义一致,spawn 只是缓存空=提速失效非错误);
# - **仅单次构建内 memo,跨构建不失效**(审查 P1-2 实测:同进程二次 build
#   会拿首次结论——"先坏后好"方向会误拒、报错指向被带偏)。build_official_datasets
#   入口主动 clear 一次(见函数首行),同进程多次构建互不残留,单次构建内去重
#   语义不变;勿改成 lru_cache/mtime 键(布尔结果同样适用但排查时更难 invalidate)。
_UNION_READABLE_CACHE: Dict[str, bool] = {}


def build_official_datasets(
    root: str,
    xlsx_path: str,
    img_size: int = 512,
    val_frac: float = 0.2,
    seed: int = 42,
    train_transform=None,
    sheet_name: str = "ROI级别",
    hflip_prob: float = 0.0,
    samples_pkl: Optional[str] = None,
    union_mask: bool = False,
    roi_meta: bool = False,
) -> Tuple["OfficialThyroidDataset", "OfficialThyroidDataset"]:
    """便捷入口:构样本 → 患者分组切分 → 建 train/val Dataset。返回 (train_ds, val_ds)。

    分组切分复用 `patient_grouped_split`(按 patient_key 分组、label 分层),防同患者
    跨集泄漏(rules.md §5)。val 集不加增强(含 hflip=0:翻转会改位置标签,验证侧必须
    用原始朝向)。DataLoader/Sampler 由调用方按训练脚本组装。

    ⚠️ `seed` **只喂给切分**,不传给 Dataset —— Dataset 的翻转 RNG 必须留 None 走全局
    random(由 DataLoader 的 worker_init_fn 每 worker/每 epoch 播种)。曾把这个 seed
    一并传下去,实测导致翻转序列跨 epoch 逐位相同,见 `OfficialThyroidDataset.__init__`。

    `samples_pkl`:预抽取产物 `<cache-dir>/samples.pkl`(见
    `scripts/data/preextract_dynamic.py`)。给了就**跳过整个扫描重建**——原路径要重扫
    xlsx 并为定位动态非零帧解压 343 个 mask,实测 10-25 分钟,每次启动都付一遍。
    pkl 里的动态样本自带 `cache_img`/`cache_msk`,`__getitem__` 随之走 PNG 而非 .nii.gz。
    切分仍在此处按同一 `seed`/`val_frac` 现算,故换 seed 不必重跑预抽取。

    `roi_meta`(2026-09-25 训练侧接线,债4 数据半):True 时 build 路径带
    `roi_meta=True`(样本携带 `roi_lesions`,供 ROI train loader 经
    `expand_roi_samples` 展开)。🔴 **与 samples_pkl 组合时做内容级双向校验**
    (2026-09-26 R3 P0-1 修,与 union 同型):roi_meta=True 但 pkl 无键 → 拒
    (旧模式产物);roi_meta=False 但 pkl 带键 → 拒(半开态)。**重建 roi 版
    pkl 的命令 = `preextract_dynamic --roi-meta`**(此前该旗标不存在,roi 版
    pkl 结构性不可产出,是 R3 P0-1 的根因)。默认 False 零回归。
    """
    # P1-2 修(2026-09-23 审查):memo 缓存每次构建清零 —— "先坏后修好再二次
    # 构建"场景不拿首次结论(残留会让报错指向"数据侧事故"而真因是缓存);
    # 单次构建内去重语义不变(同图样本共享 mask 集,同文件解 N 遍 → 1 遍)。
    _UNION_READABLE_CACHE.clear()
    if samples_pkl:
        samples, meta = _load_samples_pkl(samples_pkl)
        cached_size = meta.get("img_size")
        if cached_size is not None and int(cached_size) != int(img_size):
            # 🔴 2026-09-11 由 WARN 升级为 raise(分辨率实验教训,长期保留):
            # 旧实现只 WARN 不拦,命中旧分辨率缓存时 __getitem__ 会把缓存 PNG
            # 上采样插值到训练 img_size —— 训练照跑、日志照出、分辨率收益归零,
            # 属"合法但全错"。任何改 img_size 的实验下这都等于白烧整轮
            # (预抽取 45min+ + 训练 1h+)。
            # 该分支只在"缓存分辨率≠训练分辨率"时触发,同分辨率正常路径不受影响。
            # ⚠️ 仍剩一条绕过路径(结构性,见 preextract_dynamic 的 frame_key):
            # 复用旧 cache-dir 换 --img-size 重跑,旧 PNG 因 frame_key 不含分辨率
            # 被原样保留,新 samples.pkl 的 meta 会"声称"新分辨率 → 本 raise 不
            # 触发。故换分辨率必须用全新 --cache-dir(物理隔离是唯一可靠解)。
            raise RuntimeError(
                f"预抽取缓存 img_size={cached_size} != 训练 img_size={img_size},"
                f"缓存帧会被二次 resize(静默掉画质,分辨率实验收益归零)。"
                f"重跑预抽取: scripts/data/preextract_dynamic.py --img-size {img_size} "
                f"(换分辨率须用全新 --cache-dir —— frame_key 不含 img_size,复用旧 "
                f"frames/ 目录会静默保留旧分辨率 PNG 且 meta 谎报新分辨率)")
        if meta.get("partial"):
            # 🔴 硬拒而非告警:`--limit N` 的 pkl 只覆盖 N 个动态影像文件,其余动态样本
            # 没有缓存、会**静默回落**到全量解压的原路径 —— 既没提速又只验了一小部分,
            # 而表面上训练照跑、日志照出。这正是"合法但全错"那一类,必须堵死在入口。
            raise RuntimeError(
                f"{samples_pkl} 是 --limit 模式产出的残件(_meta.partial=True),不能用于训练。"
                f"去掉 --limit 重跑 scripts/data/preextract_dynamic.py 生成完整缓存")
        # 🔴 L2 union/pkl 一致性双向校验(2026-09-22 路B审查 P0-1/P2-1 修):
        # 首版把 gate 写在载入前且条件是 union_mask 本身——union 版 pkl 也被拒,
        # 云端链 --union-mask + --samples-pkl 第 0 步必炸,整线结构性不可达。
        # 改为**载入后按内容判**:
        #   ① union_mask=True 但 pkl 无任何样本带 union_mask_paths 键 → 旧模式
        #      pkl,静默回落 = "号称 union 实际没开"(与 --limit 残件同类),拒;
        #   ② union_mask=False 但 meta 标记/样本带键(union 版 pkl) → 半开态:
        #      __getitem__ 见键即走 union 分支,操作者以为关了实际开着,拒;
        #   ③ 一致 → 放行(union pkl + union_mask=True 是合法组合)。
        #   (路C F3,2026-09-22)isinstance 短路:非 dict 样本(手改/半写损坏 pkl)
        #   不在此抛裸 TypeError——gate 的 RuntimeError 域是 union/pkl 一致性,
        #   损坏 pkl 的报错落在既有漂移过滤(与 L2 前行为一致)。
        _has_ukey = any(isinstance(s, dict) and "union_mask_paths" in s
                        for s in samples)
        if union_mask and not _has_ukey:
            raise RuntimeError(
                f"union_mask=True 但 {samples_pkl} 无 union_mask_paths 键(旧模式产物,"
                f"静默回落单病灶监督 = 号称 union 实际没开)。用 scripts/data/"
                f"preextract_dynamic.py --union-mask 重新生成 pkl(frame_key 输入不同,"
                f"不会覆盖旧缓存)。")
        if not union_mask and (_has_ukey or meta.get("union_mask")):
            raise RuntimeError(
                f"{samples_pkl} 是 union 版 pkl(meta.union_mask={bool(meta.get('union_mask'))}),"
                f"但调用方未传 union_mask=True → 半开态:样本带键即走 union 分支,"
                f"操作者以为关了实际开着。要么传 union_mask=True,要么用旧模式 pkl。")
        # 🔴 R3 review P0-1 修(2026-09-26):roi_meta 的**内容级正向断言**
        # (与 union 的①②同型,补齐 roi 侧的不对称)。三种组合:
        #   ① roi_meta=True 但 pkl 无任何 roi_lesions 键 → 旧模式 pkl,
        #      ROI loader 0 样本 = "号称开了 ROI 实际没开",拒(比训练启动期
        #      的 len==0 守卫更早、指向产物本身);
        #   ② roi_meta=False 但样本带 roi_lesions(roi 版 pkl) → 半开态:
        #      下游按需读键不受影响,但操作者认知与产物不符 → 拒(同 union ②);
        #   ③ 一致 → 放行。直建路径(else 分支)不经过本断言——build 时
        #      roi_meta 即真实参,无"产物声称"可漂移。
        _has_rkey = any(isinstance(s, dict) and "roi_lesions" in s
                        for s in samples)
        if roi_meta and not _has_rkey:
            raise RuntimeError(
                f"roi_meta=True 但 {samples_pkl} 无 roi_lesions 键(旧模式产物,"
                f"ROI train loader 将 0 样本)。用 scripts/data/preextract_dynamic.py "
                f"--roi-meta 重新生成 pkl。")
        if not roi_meta and _has_rkey:
            raise RuntimeError(
                f"{samples_pkl} 是 roi_meta 版 pkl(样本带 roi_lesions 键),"
                f"但调用方未传 roi_meta=True → 半开态。要么传 roi_meta=True,"
                f"要么用旧模式 pkl。")
    else:
        samples = build_official_samples(
            root, xlsx_path, sheet_name, union_mask=union_mask, roi_meta=roi_meta)
    if not samples:
        raise RuntimeError(f"未在 {root} + {xlsx_path} 构造出任何样本,检查路径/表头")
    # 🔴 pkl 加载路径的文件级漂移防御(2026-09-14 实证):pkl 是历史快照,生成
    # 后官方数据侧可能删/改文件(9-12 晚 ete_only 还能跑、9-14 同一份 pkl 已有
    # 2 img + 21 mask 消失——xlsx 引用了不存在的 DICOM 子目录)。build 路径
    # 自带 exists 过滤(:543)不受影响,只有 pkl 路径无防御;DataLoader worker
    # 里炸 FileNotFoundError 会整轮崩。按样本级过滤:img 或 mask 任一缺失即
    # 丢弃该样本并打点(量级 <1% 属数据漂移噪声;大规模消失才值得停机排查,
    # 阈值 5% 超限即 raise,防"过滤掩盖真事故"——如挂载半掉线时几乎全缺)。
    _before = len(samples)
    _dropped = []
    for _s in samples[:]:
        _ip, _mp = _s.get("img_path"), _s.get("mask_path")
        _bad = (_ip and not os.path.exists(_ip)) or (_mp and not os.path.exists(_mp))
        # L2(路B P1-1,2026-09-22 修):union 样本的全部并集路径纳入 exists 校验。
        # 缺任何一个 → 剔除**该样本**(该图 union 监督不完整,留用会把次病灶
        # 静默退化为未标注背景=错误负监督,污染 L1 归因基座);阈值仍按样本级
        # 5% 口径(分母不变,缺路径样本进分子——口径写进 docstring 见上方注释)。
        for _up in _s.get("union_mask_paths") or ():
            # 路C F1/F2(2022-09-22):exists 只拦"文件消失"型漂移;**存在但读不出**
            # (9-14 invalid block type 型损坏)会被消费端 `_static_union_mask`/
            # `_dynamic_union_mask_frame` 静默 OR 恒等元吸收 → 次病灶静默退化为
            # 错误负监督,零反馈。漂移过滤是 pkl 载入时一次性成本(非每 epoch),
            # 此处真解压一次即同时校验存在与可读;读失败视同文件缺失,进同一 5% 口径。
            # 🔴 2026-09-23 启动提速热修:同一图的全部 union 样本共享同一 mask 集
            # (union_mask_paths 内容相同),逐样本真解压 = 同一文件解 N 遍(N=样本数,
            # K≥2 图实测 3.44 帧/病灶 × K)。进程内 memo 缓存(path → bool 可读),
            # 同一轮启动内重复路径零重复解压;**故意的全局可变缓存**(无并发写:
            # build_official_datasets 在 DataLoader worker fork 前的主进程单线程跑),
            # 勿改成 functools.lru_cache——它按参数哈希缓存,布尔结果同样适用但
            # 排查路径时更难 invalidate。
            if _up in _UNION_READABLE_CACHE:
                if not _UNION_READABLE_CACHE[_up]:
                    _bad = True
                    break
                continue
            _readable = bool(_read_nifti_binmasks(_up)[0])
            _UNION_READABLE_CACHE[_up] = _readable
            if not _readable:
                _bad = True
                break
        if _bad:
            _dropped.append(_s.get("patient_key", "?"))
            samples.remove(_s)
    if _dropped:
        _frac = len(_dropped) / _before
        print(f"--> [official_loader] ⚠️ 过滤 {len(_dropped)}/{_before} 个文件缺失样本"
              f"({', '.join(sorted(set(_dropped))[:8])}),占比 {_frac:.2%}")
        if _frac > 0.05:
            raise RuntimeError(
                f"文件缺失样本占比 {_frac:.1%} > 5% —— 疑似数据侧事故(挂载/官方更新),"
                f"非正常漂移,停机排查勿盲跑")
    train_s, val_s = patient_grouped_split(samples, val_frac=val_frac, seed=seed)
    train_ds = OfficialThyroidDataset(train_s, img_size=img_size, transform=train_transform,
                                      hflip_prob=hflip_prob)
    val_ds = OfficialThyroidDataset(val_s, img_size=img_size, transform=None)
    return train_ds, val_ds
